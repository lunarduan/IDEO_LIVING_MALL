﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class Shop : MonoBehaviour {
	public GameObject x;

	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.CompareTag("Player"))
		{
			x.SetActive (true);
		
			if (Input.GetKeyDown("e"))
			{

				Application.LoadLevel(3);
			}
		}
	}
	void OnTriggerStay2D(Collider2D col)
	{
		if(col.CompareTag("Player"))
		{
			if (Input.GetKeyDown("e"))
			{
				
				Application.LoadLevel(3);
			}
		}
	}
	void OnTriggerExit2D(Collider2D col)
	{
		if (col.CompareTag("Player"))
		{
			x.SetActive (false);
		}
	}
	public void gotoshoppingmall()
	{
		Application.LoadLevel(2);
	}

		
}
