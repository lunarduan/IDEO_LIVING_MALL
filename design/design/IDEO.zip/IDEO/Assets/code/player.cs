﻿using UnityEngine;
using System.Collections;

public class player : MonoBehaviour
{
	private bool _IsFacingRight;
	public float maxSpeed = 3;
	public float speed = 50f;

	public bool facingRight = true;



	private Rigidbody2D rb2d;
	private Animator anim;
	private SpriteRenderer spr;


	void Start()
	{
		
		anim = gameObject.GetComponent<Animator>();
		rb2d = gameObject.GetComponent<Rigidbody2D>();
		//rb2d.velocity = new Vector2(maxSpeed, rb2d.velocity.x);
		spr.gameObject.GetComponent<SpriteRenderer>();
	   
	}

	void Update()
	{

	

	}
	void FixedUpdate()
	{


		float h = Input.GetAxis("Horizontal");
		//Fake friction / Easing the x speed of our player

	
		if (Input.GetKey(KeyCode.D)||Input.GetKey(KeyCode.RightArrow))
		{

			if (!_IsFacingRight)
				spr.flipX;
			facingRight = true;


		}
		else if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
		{

			if (_IsFacingRight)
				transform.localScale =spr.flipX;
			facingRight = false;

		}



	
	}
	private void Flip()
	{
		transform.localScale = new Vector3(-transform.localScale.x, transform.localScale.y, transform.localScale.z);
		_IsFacingRight = transform.localScale.x > 0;
	}

}

