﻿using UnityEngine;
using System.Collections;

public class player : MonoBehaviour
{
	private bool _IsFacingRight;
	public float maxSpeed = 3;
	public float speed = 50f;

	public bool facingRight = true;



	private Rigidbody2D rb2d;
	private Animator anim;
	private SpriteRenderer mySpriteRenderer;

	private void Awake()
	{
		// get a reference to the SpriteRenderer component on this gameObject
		mySpriteRenderer = GetComponent<SpriteRenderer>();
	}
	void Start()
	{
		
		anim = gameObject.GetComponent<Animator>();
		rb2d = gameObject.GetComponent<Rigidbody2D>();
		rb2d.velocity = new Vector2(0, rb2d.velocity.x);
	
	   
	}

	void Update()
	{


		if (Input.GetKey(KeyCode.D)||Input.GetKey(KeyCode.RightArrow))
		{


				
			mySpriteRenderer.flipX = true;
			rb2d.velocity = new Vector2(2, rb2d.velocity.x);


		}
		else if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
		{



			mySpriteRenderer.flipX = false;
			rb2d.velocity = new Vector2(-2, rb2d.velocity.x);
		}
		else if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
		{




			rb2d.velocity = new Vector2(0, rb2d.velocity.x);
		}
	

	}
	void FixedUpdate()
	{


		float h = Input.GetAxis("Horizontal");
		//Fake friction / Easing the x speed of our player

	



	
	}
	private void Flip()
	{
		
	}

}

